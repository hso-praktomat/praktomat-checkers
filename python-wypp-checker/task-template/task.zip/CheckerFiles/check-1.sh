#!/bin/bash

python3 /check.py 1
