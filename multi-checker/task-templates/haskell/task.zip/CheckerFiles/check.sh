#!/bin/bash

export HOME=/root
python3 /checker/check.py haskell
