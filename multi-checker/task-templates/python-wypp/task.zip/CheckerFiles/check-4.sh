#!/bin/bash

python3 /check.py --kind python-wypp 4
