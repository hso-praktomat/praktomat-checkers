#!/bin/bash

python3 /checker/check.py python --assignment 3
