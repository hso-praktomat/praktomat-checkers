#!/bin/bash

python3 /checker/check.py python-wypp --assignment 5
